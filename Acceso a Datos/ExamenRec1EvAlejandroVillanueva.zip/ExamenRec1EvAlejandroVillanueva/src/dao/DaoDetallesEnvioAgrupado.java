package dao;

import beans.DetalleEnvioAgrupado;
import motor.MotorDerby;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DaoDetallesEnvioAgrupado {

    private String sql = "SELECT * FROM ";
    private MotorDerby motorDerby;
    public DaoDetallesEnvioAgrupado() {
        this.motorDerby = new MotorDerby();
    }
    public ArrayList<DetalleEnvioAgrupado> muestraAgrupado(DetalleEnvioAgrupado bean) {
        motorDerby.connect();
        String tablaNombre = "detalles_envio_agrupado";
        String SQL = sql + tablaNombre + "where 1=1";
        ArrayList<DetalleEnvioAgrupado> listaDetalleAgrupado = new ArrayList<>();
        ResultSet resultSet;
        resultSet = motorDerby.executeQuery(SQL);

        try {
            while (resultSet.next()) {
                DetalleEnvioAgrupado detalleEnvioAgrupado = new DetalleEnvioAgrupado();
                detalleEnvioAgrupado.setIdDetalleEnvio(resultSet.getInt(1));
                detalleEnvioAgrupado.setIdEnvioAgrupado(resultSet.getInt(2));
                detalleEnvioAgrupado.setIdDetalleCompra(resultSet.getInt(3));

                listaDetalleAgrupado.add(detalleEnvioAgrupado);
            }
        } catch (SQLException ex) {
            Logger.getLogger(DaoDetallesEnvioAgrupado.class.getName()).log(Level.SEVERE, null, ex);
        }

        motorDerby.close();
        return listaDetalleAgrupado;
    }
}
