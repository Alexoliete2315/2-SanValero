package dao;

import beans.Compra;
import beans.DetalleEnvioAgrupado;
import motor.MotorDerby;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DaoCompras {

    private String sql = "SELECT * FROM ";
    private MotorDerby motorDerby;
    public DaoCompras() {
        this.motorDerby = new MotorDerby();
    }
    public ArrayList<Compra> muestraAgrupado(Compra bean) {
        motorDerby.connect();
        String tablaNombre = "compras";
        String SQL = sql + tablaNombre + "where 1=1";
        ArrayList<Compra> listaCompras = new ArrayList<>();
        ResultSet resultSet;
        resultSet = motorDerby.executeQuery(SQL);

        try {
            while (resultSet.next()) {
                Compra compra = new Compra();
                compra.setIdCompra(resultSet.getInt(1));
                compra.setIdCliente(resultSet.getInt(2));
                compra.setFechaCompra(resultSet.getDate(3));
                compra.setEsAgrupada(resultSet.getInt(4));

                listaCompras.add(compra);
            }
        } catch (SQLException ex) {
            Logger.getLogger(DaoCompras.class.getName()).log(Level.SEVERE, null, ex);
        }

        motorDerby.close();
        return listaCompras;
    }
}
