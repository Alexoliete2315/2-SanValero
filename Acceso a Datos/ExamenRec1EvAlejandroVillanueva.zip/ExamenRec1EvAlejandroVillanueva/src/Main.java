import beans.Compra;
import beans.DetalleEnvioAgrupado;
import dao.DaoCompras;
import dao.DaoDetallesEnvioAgrupado;
import motor.MotorDerby;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        MotorDerby motorDerby = new MotorDerby();
        ResultSet resultSet;

        int opcion;
        do {
            System.out.println("MENÚ");
            System.out.println("1.MOSTRAR detalles envipo agrupados");
            System.out.println("2.MOSTRAR COMPRAS");
            System.out.println("0.SALIR");
            // Obtener la opción del usuario
            System.out.print("Elige una opción: ");
            opcion = scanner.nextInt();


            switch (opcion) {
                case 1:
                    motorDerby.connect();
                    String SQL = "SELECT * FROM detalles_envio_agrupado where 1=1";
                    System.out.println(SQL);
                    ArrayList<DetalleEnvioAgrupado> listaDetalleEnvioAgrupado = new ArrayList<>();
                    resultSet = motorDerby.executeQuery(SQL);

                    try {
                        while (resultSet.next()) {
                            DetalleEnvioAgrupado detalleEnvioAgrupado = new DetalleEnvioAgrupado();
                            detalleEnvioAgrupado.setIdDetalleEnvio(resultSet.getInt(1));
                            detalleEnvioAgrupado.setIdEnvioAgrupado(resultSet.getInt(2));
                            detalleEnvioAgrupado.setIdDetalleCompra(resultSet.getInt(3));

                            listaDetalleEnvioAgrupado.add(detalleEnvioAgrupado);
                        }
                    } catch (SQLException ex) {
                        Logger.getLogger(DaoDetallesEnvioAgrupado.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    for (DetalleEnvioAgrupado detalleEnvioAgrupado : listaDetalleEnvioAgrupado) {
                        System.out.println(detalleEnvioAgrupado.toString());
                    }
                    motorDerby.close();
                    break;


                case 2:
                    motorDerby.connect();
                    String SQL1 = "SELECT * FROM compras where 1=1";
                    System.out.println(SQL1);
                    ArrayList<Compra> listaCompras = new ArrayList<>();
                    resultSet = motorDerby.executeQuery(SQL1);

                    try {
                        while (resultSet.next()) {
                            Compra compra = new Compra();
                            compra.setIdCompra(resultSet.getInt(1));
                            compra.setIdCliente(resultSet.getInt(2));
                            compra.setFechaCompra(resultSet.getDate(3));
                            compra.setEsAgrupada(resultSet.getInt(4));

                            listaCompras.add(compra);
                        }
                    } catch (SQLException ex) {
                        Logger.getLogger(DaoCompras.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    for (Compra compra: listaCompras) {
                        System.out.println(compra.toString());
                    }

                    motorDerby.close();
                    break;
            }
            }while (opcion != 0) ;
            scanner.close();

    }
}

