package beans;

import java.util.Date;

import java.util.Date;

public class Compra {

    private int idCompra;
    private int idCliente;
    private Date fechaCompra;
    private int esAgrupada; //0 o 1 flase o true

    // Constructor
    public Compra() {
    }

    // Constructor con parámetros
    public Compra(int idCompra, int idCliente, Date fechaCompra, int esAgrupada) {
        this.idCompra = idCompra;
        this.idCliente = idCliente;
        this.fechaCompra = fechaCompra;
        this.esAgrupada = esAgrupada;
    }

    // Getters y setters

    public int getIdCompra() {
        return idCompra;
    }

    public void setIdCompra(int idCompra) {
        this.idCompra = idCompra;
    }

    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }

    public Date getFechaCompra() {
        return fechaCompra;
    }

    public void setFechaCompra(Date fechaCompra) {
        this.fechaCompra = fechaCompra;
    }

    public int isEsAgrupada() {
        return esAgrupada;
    }

    public void setEsAgrupada(int esAgrupada) {
        this.esAgrupada = esAgrupada;
    }

    // Método toString para facilitar la impresión de la información de la compra
    @Override
    public String toString() {
        return "Compra{" +
                "idCompra=" + idCompra +
                ", idCliente=" + idCliente +
                ", fechaCompra=" + fechaCompra +
                ", esAgrupada=" + esAgrupada +
                '}';
    }
}
