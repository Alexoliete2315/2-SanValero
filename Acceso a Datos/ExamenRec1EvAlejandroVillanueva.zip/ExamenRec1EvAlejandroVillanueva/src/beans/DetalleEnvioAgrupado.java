package beans;

public class DetalleEnvioAgrupado {

    private int idDetalleEnvio;
    private int idEnvioAgrupado;
    private int idDetalleCompra;

    // Constructor
    public DetalleEnvioAgrupado() {
    }

    // Constructor con parámetros
    public DetalleEnvioAgrupado(int idDetalleEnvio, int idEnvioAgrupado, int idDetalleCompra) {
        this.idDetalleEnvio = idDetalleEnvio;
        this.idEnvioAgrupado = idEnvioAgrupado;
        this.idDetalleCompra = idDetalleCompra;
    }

    // Getters y setters

    public int getIdDetalleEnvio() {
        return idDetalleEnvio;
    }

    public void setIdDetalleEnvio(int idDetalleEnvio) {
        this.idDetalleEnvio = idDetalleEnvio;
    }

    public int getIdEnvioAgrupado() {
        return idEnvioAgrupado;
    }

    public void setIdEnvioAgrupado(int idEnvioAgrupado) {
        this.idEnvioAgrupado = idEnvioAgrupado;
    }

    public int getIdDetalleCompra() {
        return idDetalleCompra;
    }

    public void setIdDetalleCompra(int idDetalleCompra) {
        this.idDetalleCompra = idDetalleCompra;
    }

    // Método toString para facilitar la impresión de la información del detalle de envío agrupado
    @Override
    public String toString() {
        return "DetalleEnvioAgrupado{" +
                "idDetalleEnvio=" + idDetalleEnvio +
                ", idEnvioAgrupado=" + idEnvioAgrupado +
                ", idDetalleCompra=" + idDetalleCompra +
                '}';
    }
}
