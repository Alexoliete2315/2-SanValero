package bean;

public class DireccionEnvio {
    private int idDireccionEnvio;

    public DireccionEnvio(int idDireccionEnvio) {
        this.idDireccionEnvio = idDireccionEnvio;
    }

    public int getIdDireccionEnvio() {
        return idDireccionEnvio;
    }

    public void setIdDireccionEnvio(int idDireccionEnvio) {
        this.idDireccionEnvio = idDireccionEnvio;
    }
}
