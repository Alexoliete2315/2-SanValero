package dao;

import bean.DetalleNotaPago;
import bean.Ticket;
import motor.MotorDerby;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DaoClientes {

    private String sql = "SELECT * FROM ";
    private MotorDerby motorDerby;
    public DaoClientes() {

        this.motorDerby = new MotorDerby();
    }

    //COMPLETAR MOSTRANDO EL TICKET
    public ArrayList<Ticket> muestrTicket(Ticket bean) {
        motorDerby.connect();
        String tablaNombre = "TICKET";
        String SQL = sql + tablaNombre + "where 1=1";
        ArrayList<Ticket> listaTickets = new ArrayList<>();
        ResultSet resultSet;
        resultSet = motorDerby.executeQuery(SQL);

        try {
            while (resultSet.next()) {
                Ticket ticket = new Ticket();
                ticket.setIdDetalleNota(resultSet.getInt(1));
                ticket.setIdJuguete(resultSet.getInt(2));
                ticket.setCantidad(resultSet.getInt(3));
                listaDetalleNota.add(detalleNota);
            }
        } catch (SQLException ex) {
            Logger.getLogger(DaoProveedores.class.getName()).log(Level.SEVERE, null, ex);
        }

        motorDerby.close();
        return listaDetalleNota;
    }
}
