package main;



import motor.MotorDerby;


import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
                Scanner scanner = new Scanner(System.in);
                MotorDerby motorDerby = new MotorDerby();

                int opcion;

                do {
                    // Mostrar el menú
                    System.out.println("Menú:");
                    System.out.println("1.  DETALLES NOTA DE PAGO");
                    System.out.println("2. DETALLES DE PEDIDO");
                    System.out.println("3.  DETALLES ALBARAN");
                    System.out.println("0. Salir");

                    // Obtener la opción del usuario
                    System.out.print("Elige una opción: ");
                    opcion = scanner.nextInt();

                    // Realizar acciones según la opción seleccionada
                    switch (opcion) {
                        case 1:
                            //motorDerby.executeQuery();
                            break;
                        case 2:
                            System.out.println("Seleccionaste la Opción 2");

                            break;
                        case 3:
                            System.out.println("Seleccionaste la Opción 3");

                            break;
                        case 0:
                            System.out.println("Saliendo del programa. ¡Hasta luego!");
                            break;
                        default:
                            System.out.println("Opción no válida. Por favor, elige una opción válida.");
                            break;
                    }

                } while (opcion != 0);

                scanner.close();
            }
        }
