    public class Main {
    public static void main(String[] args) {
        JulioCesar julioCesar = new JulioCesar(5000);
    }
}