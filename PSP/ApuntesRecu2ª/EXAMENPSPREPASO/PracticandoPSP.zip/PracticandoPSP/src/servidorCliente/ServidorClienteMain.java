package servidorCliente;

public class ServidorClienteMain {
    public static void main(String[] args) {

            ServidorCliente servidorCliente = new ServidorCliente("localhost",5000);



    }
}