public class Main {
    public static void main(String[] args) {
//        for (int i = 0; i < 5; i++) {
            Centurion centurion = new Centurion("localhost", 5000);
//        }
    }
}