public class Main {
    public static void main(String[] args) {
//        for (int i = 0; i < 4; i++) {
            Legionario legionario = new Legionario("localhost", 5001);
//        }
    }
}