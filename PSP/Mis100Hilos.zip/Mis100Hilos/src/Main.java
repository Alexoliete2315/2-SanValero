import java.util.ArrayList;
import java.util.List;

public class Main {
    static Contador contador = new Contador();
    public static void main(String[] args) {
        contador.setValor(0);


        for (int i = 1; i < 101; i++) {
            Hilo hilo = new Hilo(contador,i);
            hilo.run();
        }

    }

}
