public class Hilo extends Thread {
    private Contador contador;
    private int numeroHilo;

    public Hilo(Contador contador, int numeroHilo) {
        this.contador = contador;
        this.numeroHilo = numeroHilo;
    }

    @Override
    public void run() {
        int valorCount = Main.contador.getValor();
        String print = " Soy el hilo: " + numeroHilo + " El valor era: " + contador.getValor();
        valorCount++;
        Main.contador.setValor(valorCount);
//        System.out.println( print+ " ahora es: " + valorCount);
        System.out.println( print+ " ahora es: " + contador.getValor());
    }

}
